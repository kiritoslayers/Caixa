﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Caixa : Form
    {
        public Caixa()
        {
            InitializeComponent();
        }


        public static List<Conta> ContasAbertas = new List<Conta>();
        

        private void panelMenuFill_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private Form2 abrirConta = null;
        private void btAbrirConta_Click(object sender, EventArgs e)
        {
            this.abrirConta = new Form2(ContasAbertas);
            abrirConta.ShowDialog();
        }

        private Navegar web = null;
        private void btPLanos_Click(object sender, EventArgs e)
        {
            this.web = new Navegar();
            web.ShowDialog();
        }


        private Form3 Contas = null;
        private void btExibirContas_Click_1(object sender, EventArgs e)
        {
            this.Contas = new Form3(ContasAbertas);
            this.Contas.ShowDialog();
        }

    }

}


