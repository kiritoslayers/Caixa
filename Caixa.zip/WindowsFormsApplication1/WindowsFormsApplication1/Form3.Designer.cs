﻿namespace WindowsFormsApplication1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btExbirContas = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.contas = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btExbirContas
            // 
            this.btExbirContas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Orange;
            this.btExbirContas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Goldenrod;
            this.btExbirContas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExbirContas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btExbirContas.Location = new System.Drawing.Point(261, 61);
            this.btExbirContas.Name = "btExbirContas";
            this.btExbirContas.Size = new System.Drawing.Size(183, 44);
            this.btExbirContas.TabIndex = 1;
            this.btExbirContas.Text = "Exibir Contas";
            this.btExbirContas.UseVisualStyleBackColor = true;
            this.btExbirContas.Click += new System.EventHandler(this.btExbirContas_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(713, 36);
            this.panelTop.TabIndex = 23;
            // 
            // contas
            // 
            this.contas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.contas.FormattingEnabled = true;
            this.contas.Location = new System.Drawing.Point(0, 130);
            this.contas.Name = "contas";
            this.contas.Size = new System.Drawing.Size(713, 238);
            this.contas.TabIndex = 24;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 368);
            this.Controls.Add(this.contas);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.btExbirContas);
            this.Name = "Form3";
            this.Text = "Contas";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btExbirContas;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.ListBox contas;
    }
}