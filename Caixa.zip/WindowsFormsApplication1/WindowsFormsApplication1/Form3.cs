﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public List<Conta> ContasAbertas = new List<Conta>();
        public Form3(List<Conta> ContasAbertasForm1)
        {
            InitializeComponent();
            ContasAbertas = ContasAbertasForm1;
        }


        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void btExbirContas_Click(object sender, EventArgs e)
        {
            foreach (var item in ContasAbertas)
            {
                    contas.Items.Add(item.Nome);
                    contas.Items.Add(item.Cpf);
                    contas.Items.Add(item.DataNascimento);
                    contas.Items.Add(item.Idade);
                    contas.Items.Add(item.Telefone);
                    contas.Items.Add(item.Endereco);
                    contas.Items.Add(item.Complemento);
                    contas.Items.Add(item.Email);
                    contas.Items.Add(item.Empresa);
                    contas.Items.Add(item.Saldo);

            }
        }

    }
}

