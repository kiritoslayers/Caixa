﻿namespace WindowsFormsApplication1
{
    partial class Caixa
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Caixa));
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelMenuVertical = new System.Windows.Forms.Panel();
            this.btExibirContas = new System.Windows.Forms.Button();
            this.btPLanos = new System.Windows.Forms.Button();
            this.btAbrirConta = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.logoCaixa = new System.Windows.Forms.PictureBox();
            this.panelMenuDireita = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbTexto4 = new System.Windows.Forms.Label();
            this.lbCaixaTem = new System.Windows.Forms.Label();
            this.lbTexo3 = new System.Windows.Forms.Label();
            this.lbTexto2 = new System.Windows.Forms.Label();
            this.lbTexto = new System.Windows.Forms.Label();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbCaixa = new System.Windows.Forms.Label();
            this.panelMenuVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoCaixa)).BeginInit();
            this.panelMenuDireita.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1150, 41);
            this.panelTop.TabIndex = 0;
            // 
            // panelMenuVertical
            // 
            this.panelMenuVertical.BackColor = System.Drawing.Color.AliceBlue;
            this.panelMenuVertical.Controls.Add(this.btExibirContas);
            this.panelMenuVertical.Controls.Add(this.btPLanos);
            this.panelMenuVertical.Controls.Add(this.btAbrirConta);
            this.panelMenuVertical.Controls.Add(this.btSair);
            this.panelMenuVertical.Controls.Add(this.logoCaixa);
            this.panelMenuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenuVertical.Location = new System.Drawing.Point(0, 41);
            this.panelMenuVertical.Name = "panelMenuVertical";
            this.panelMenuVertical.Size = new System.Drawing.Size(288, 457);
            this.panelMenuVertical.TabIndex = 1;
            // 
            // btExibirContas
            // 
            this.btExibirContas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btExibirContas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gold;
            this.btExibirContas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
            this.btExibirContas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExibirContas.Image = ((System.Drawing.Image)(resources.GetObject("btExibirContas.Image")));
            this.btExibirContas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btExibirContas.Location = new System.Drawing.Point(3, 150);
            this.btExibirContas.Name = "btExibirContas";
            this.btExibirContas.Size = new System.Drawing.Size(283, 34);
            this.btExibirContas.TabIndex = 12;
            this.btExibirContas.Text = "Exibir Contas";
            this.btExibirContas.UseVisualStyleBackColor = true;
            this.btExibirContas.Click += new System.EventHandler(this.btExibirContas_Click_1);
            // 
            // btPLanos
            // 
            this.btPLanos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btPLanos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gold;
            this.btPLanos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
            this.btPLanos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPLanos.Image = ((System.Drawing.Image)(resources.GetObject("btPLanos.Image")));
            this.btPLanos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btPLanos.Location = new System.Drawing.Point(2, 190);
            this.btPLanos.Name = "btPLanos";
            this.btPLanos.Size = new System.Drawing.Size(283, 34);
            this.btPLanos.TabIndex = 4;
            this.btPLanos.Text = "Planos";
            this.btPLanos.UseVisualStyleBackColor = true;
            this.btPLanos.Click += new System.EventHandler(this.btPLanos_Click);
            // 
            // btAbrirConta
            // 
            this.btAbrirConta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btAbrirConta.BackgroundImage")));
            this.btAbrirConta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btAbrirConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAbrirConta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gold;
            this.btAbrirConta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
            this.btAbrirConta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAbrirConta.Location = new System.Drawing.Point(3, 110);
            this.btAbrirConta.Name = "btAbrirConta";
            this.btAbrirConta.Size = new System.Drawing.Size(283, 34);
            this.btAbrirConta.TabIndex = 1;
            this.btAbrirConta.Text = "Abrir Conta";
            this.btAbrirConta.UseVisualStyleBackColor = true;
            this.btAbrirConta.Click += new System.EventHandler(this.btAbrirConta_Click);
            // 
            // btSair
            // 
            this.btSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSair.Image = ((System.Drawing.Image)(resources.GetObject("btSair.Image")));
            this.btSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btSair.Location = new System.Drawing.Point(2, 230);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(283, 34);
            this.btSair.TabIndex = 5;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = true;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // logoCaixa
            // 
            this.logoCaixa.Image = ((System.Drawing.Image)(resources.GetObject("logoCaixa.Image")));
            this.logoCaixa.Location = new System.Drawing.Point(3, -81);
            this.logoCaixa.Name = "logoCaixa";
            this.logoCaixa.Size = new System.Drawing.Size(308, 185);
            this.logoCaixa.TabIndex = 0;
            this.logoCaixa.TabStop = false;
            // 
            // panelMenuDireita
            // 
            this.panelMenuDireita.BackColor = System.Drawing.Color.DarkOrange;
            this.panelMenuDireita.Controls.Add(this.label4);
            this.panelMenuDireita.Controls.Add(this.label3);
            this.panelMenuDireita.Controls.Add(this.label2);
            this.panelMenuDireita.Controls.Add(this.lbTexto4);
            this.panelMenuDireita.Controls.Add(this.lbCaixaTem);
            this.panelMenuDireita.Controls.Add(this.lbTexo3);
            this.panelMenuDireita.Controls.Add(this.lbTexto2);
            this.panelMenuDireita.Controls.Add(this.lbTexto);
            this.panelMenuDireita.Controls.Add(this.lbTitulo);
            this.panelMenuDireita.Controls.Add(this.label1);
            this.panelMenuDireita.Controls.Add(this.lbCaixa);
            this.panelMenuDireita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMenuDireita.Location = new System.Drawing.Point(288, 41);
            this.panelMenuDireita.Name = "panelMenuDireita";
            this.panelMenuDireita.Size = new System.Drawing.Size(862, 457);
            this.panelMenuDireita.TabIndex = 2;
            this.panelMenuDireita.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMenuFill_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkOrange;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(11, 349);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 23);
            this.label4.TabIndex = 11;
            this.label4.Text = "R$ 1.200 por dia.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(10, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(800, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "consultar saldo e extrato, fazer pagamentos e transferências de até R$ 600 por tr" +
    "ansação e até";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkOrange;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(11, 303);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(776, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "serviço sociais e a diversas transações bancárias... Quem tem conta na CAIXA tamb" +
    "ém pode";
            // 
            // lbTexto4
            // 
            this.lbTexto4.AutoSize = true;
            this.lbTexto4.BackColor = System.Drawing.Color.DarkOrange;
            this.lbTexto4.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTexto4.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTexto4.Location = new System.Drawing.Point(11, 280);
            this.lbTexto4.Name = "lbTexto4";
            this.lbTexto4.Size = new System.Drawing.Size(824, 23);
            this.lbTexto4.TabIndex = 8;
            this.lbTexto4.Text = "O CAIXA Tem é o novo aplicativo da CAIXA criado para facilitar o acesso de todos " +
    "os brasileiros a";
            // 
            // lbCaixaTem
            // 
            this.lbCaixaTem.AutoSize = true;
            this.lbCaixaTem.BackColor = System.Drawing.Color.DarkOrange;
            this.lbCaixaTem.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCaixaTem.ForeColor = System.Drawing.SystemColors.Control;
            this.lbCaixaTem.Location = new System.Drawing.Point(9, 242);
            this.lbCaixaTem.Name = "lbCaixaTem";
            this.lbCaixaTem.Size = new System.Drawing.Size(131, 31);
            this.lbCaixaTem.TabIndex = 7;
            this.lbCaixaTem.Text = "Caixa Tem";
            // 
            // lbTexo3
            // 
            this.lbTexo3.AutoSize = true;
            this.lbTexo3.BackColor = System.Drawing.Color.DarkOrange;
            this.lbTexo3.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTexo3.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTexo3.Location = new System.Drawing.Point(11, 178);
            this.lbTexo3.Name = "lbTexo3";
            this.lbTexo3.Size = new System.Drawing.Size(697, 23);
            this.lbTexo3.TabIndex = 6;
            this.lbTexo3.Text = "Os beneficiários receberão R$ 2,3 bilhões em suas contas Poupança Social Digital." +
    "";
            // 
            // lbTexto2
            // 
            this.lbTexto2.AutoSize = true;
            this.lbTexto2.BackColor = System.Drawing.Color.DarkOrange;
            this.lbTexto2.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTexto2.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTexto2.Location = new System.Drawing.Point(11, 155);
            this.lbTexto2.Name = "lbTexto2";
            this.lbTexto2.Size = new System.Drawing.Size(842, 23);
            this.lbTexto2.TabIndex = 5;
            this.lbTexto2.Text = "Auxílio Emergencial Extensão para 6,6 milhões de brasileiros do ciclo 6 nascidos " +
    "em julho e agosto.";
            // 
            // lbTexto
            // 
            this.lbTexto.AutoSize = true;
            this.lbTexto.BackColor = System.Drawing.Color.DarkOrange;
            this.lbTexto.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTexto.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTexto.Location = new System.Drawing.Point(10, 131);
            this.lbTexto.Name = "lbTexto";
            this.lbTexto.Size = new System.Drawing.Size(854, 23);
            this.lbTexto.TabIndex = 4;
            this.lbTexto.Text = "A CAIXA realiza, neste domingo (20/12), mais uma etapa de pagamento do Auxílio Em" +
    "ergencial e do ";
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.BackColor = System.Drawing.Color.DarkOrange;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTitulo.Location = new System.Drawing.Point(9, 91);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(408, 31);
            this.lbTitulo.TabIndex = 3;
            this.lbTitulo.Text = "Auxilio emergencial da caixa texto";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(6, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "_________________________________";
            // 
            // lbCaixa
            // 
            this.lbCaixa.AutoSize = true;
            this.lbCaixa.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCaixa.ForeColor = System.Drawing.Color.White;
            this.lbCaixa.Location = new System.Drawing.Point(6, 17);
            this.lbCaixa.Name = "lbCaixa";
            this.lbCaixa.Size = new System.Drawing.Size(141, 35);
            this.lbCaixa.TabIndex = 0;
            this.lbCaixa.Text = "Bem Vindo!";
            // 
            // Caixa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 498);
            this.Controls.Add(this.panelMenuDireita);
            this.Controls.Add(this.panelMenuVertical);
            this.Controls.Add(this.panelTop);
            this.Name = "Caixa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Caixa";
            this.panelMenuVertical.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoCaixa)).EndInit();
            this.panelMenuDireita.ResumeLayout(false);
            this.panelMenuDireita.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelMenuVertical;
        private System.Windows.Forms.Panel panelMenuDireita;
        private System.Windows.Forms.PictureBox logoCaixa;
        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.Button btPLanos;
        private System.Windows.Forms.Button btAbrirConta;
        private System.Windows.Forms.Label lbCaixa;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbTexto4;
        private System.Windows.Forms.Label lbCaixaTem;
        private System.Windows.Forms.Label lbTexo3;
        private System.Windows.Forms.Label lbTexto2;
        private System.Windows.Forms.Label lbTexto;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btExibirContas;
    }
}

