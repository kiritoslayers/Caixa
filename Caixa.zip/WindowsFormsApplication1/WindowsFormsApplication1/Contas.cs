﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class Conta
    {
        
        public string Nome;
        public string Cpf;
        public string DataNascimento;
        public int Idade;
        public string Telefone;
        public string Endereco;
        public string Complemento;
        public string Email;
        public string Empresa;
        public float Saldo;


    }
}
