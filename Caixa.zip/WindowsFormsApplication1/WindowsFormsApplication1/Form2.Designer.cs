﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btCriarConta = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.rbCorrente = new System.Windows.Forms.RadioButton();
            this.rbPoupanca = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.lbEmpresa = new System.Windows.Forms.Label();
            this.tbCPF = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbComplemento = new System.Windows.Forms.Label();
            this.lbCPF = new System.Windows.Forms.Label();
            this.tbComplemento = new System.Windows.Forms.TextBox();
            this.lbDataNascimento = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.Idade = new System.Windows.Forms.Label();
            this.tbEmpresa = new System.Windows.Forms.TextBox();
            this.lbTelefone = new System.Windows.Forms.Label();
            this.tbDataNascimento = new System.Windows.Forms.TextBox();
            this.lbEndereco = new System.Windows.Forms.Label();
            this.tbIdade = new System.Windows.Forms.TextBox();
            this.tbEndereco = new System.Windows.Forms.TextBox();
            this.tbTelefone = new System.Windows.Forms.TextBox();
            this.painelFormulario = new System.Windows.Forms.Panel();
            this.tbSaldo = new System.Windows.Forms.TextBox();
            this.lbSaldo = new System.Windows.Forms.Label();
            this.painelTitulo = new System.Windows.Forms.Panel();
            this.painelFormulario.SuspendLayout();
            this.SuspendLayout();
            // 
            // btCriarConta
            // 
            this.btCriarConta.BackColor = System.Drawing.SystemColors.Control;
            this.btCriarConta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCriarConta.BackgroundImage")));
            this.btCriarConta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btCriarConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCriarConta.Location = new System.Drawing.Point(579, 228);
            this.btCriarConta.Name = "btCriarConta";
            this.btCriarConta.Size = new System.Drawing.Size(105, 52);
            this.btCriarConta.TabIndex = 25;
            this.btCriarConta.Text = "Criar Conta";
            this.btCriarConta.UseVisualStyleBackColor = false;
            this.btCriarConta.Click += new System.EventHandler(this.btCriarConta_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCancelar.BackgroundImage")));
            this.btCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCancelar.Location = new System.Drawing.Point(351, 228);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(105, 52);
            this.btCancelar.TabIndex = 24;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // btLimpar
            // 
            this.btLimpar.BackColor = System.Drawing.SystemColors.Control;
            this.btLimpar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btLimpar.BackgroundImage")));
            this.btLimpar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btLimpar.Location = new System.Drawing.Point(462, 228);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(105, 52);
            this.btLimpar.TabIndex = 23;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = false;
            this.btLimpar.Click += new System.EventHandler(this.btLimpar_Click);
            // 
            // rbCorrente
            // 
            this.rbCorrente.AutoSize = true;
            this.rbCorrente.Location = new System.Drawing.Point(20, 249);
            this.rbCorrente.Name = "rbCorrente";
            this.rbCorrente.Size = new System.Drawing.Size(88, 23);
            this.rbCorrente.TabIndex = 10;
            this.rbCorrente.TabStop = true;
            this.rbCorrente.Text = "Corrente";
            this.rbCorrente.UseVisualStyleBackColor = true;
            // 
            // rbPoupanca
            // 
            this.rbPoupanca.AutoSize = true;
            this.rbPoupanca.Location = new System.Drawing.Point(114, 249);
            this.rbPoupanca.Name = "rbPoupanca";
            this.rbPoupanca.Size = new System.Drawing.Size(95, 23);
            this.rbPoupanca.TabIndex = 10;
            this.rbPoupanca.TabStop = true;
            this.rbPoupanca.Text = "Poupança";
            this.rbPoupanca.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 19;
            this.label2.Text = "Tipo de Conta";
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(23, 42);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(250, 27);
            this.tbNome.TabIndex = 1;
            // 
            // lbEmpresa
            // 
            this.lbEmpresa.AutoSize = true;
            this.lbEmpresa.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmpresa.Location = new System.Drawing.Point(353, 156);
            this.lbEmpresa.Name = "lbEmpresa";
            this.lbEmpresa.Size = new System.Drawing.Size(69, 19);
            this.lbEmpresa.TabIndex = 18;
            this.lbEmpresa.Text = "Empresa";
            // 
            // tbCPF
            // 
            this.tbCPF.Location = new System.Drawing.Point(292, 42);
            this.tbCPF.Name = "tbCPF";
            this.tbCPF.Size = new System.Drawing.Size(130, 27);
            this.tbCPF.TabIndex = 2;
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmail.Location = new System.Drawing.Point(20, 156);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(53, 19);
            this.lbEmail.TabIndex = 17;
            this.lbEmail.Text = "E-mail";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNome.Location = new System.Drawing.Point(20, 16);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(52, 19);
            this.lbNome.TabIndex = 2;
            this.lbNome.Text = "Nome";
            // 
            // lbComplemento
            // 
            this.lbComplemento.AutoSize = true;
            this.lbComplemento.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbComplemento.Location = new System.Drawing.Point(523, 86);
            this.lbComplemento.Name = "lbComplemento";
            this.lbComplemento.Size = new System.Drawing.Size(108, 19);
            this.lbComplemento.TabIndex = 16;
            this.lbComplemento.Text = "Complemento";
            // 
            // lbCPF
            // 
            this.lbCPF.AutoSize = true;
            this.lbCPF.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCPF.Location = new System.Drawing.Point(288, 16);
            this.lbCPF.Name = "lbCPF";
            this.lbCPF.Size = new System.Drawing.Size(35, 19);
            this.lbCPF.TabIndex = 3;
            this.lbCPF.Text = "CPF";
            // 
            // tbComplemento
            // 
            this.tbComplemento.Location = new System.Drawing.Point(527, 111);
            this.tbComplemento.Name = "tbComplemento";
            this.tbComplemento.Size = new System.Drawing.Size(134, 27);
            this.tbComplemento.TabIndex = 7;
            // 
            // lbDataNascimento
            // 
            this.lbDataNascimento.AutoSize = true;
            this.lbDataNascimento.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDataNascimento.Location = new System.Drawing.Point(434, 16);
            this.lbDataNascimento.Name = "lbDataNascimento";
            this.lbDataNascimento.Size = new System.Drawing.Size(151, 19);
            this.lbDataNascimento.TabIndex = 4;
            this.lbDataNascimento.Text = "Data de Nascimento";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(23, 178);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(313, 27);
            this.tbEmail.TabIndex = 8;
            // 
            // Idade
            // 
            this.Idade.AutoSize = true;
            this.Idade.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idade.Location = new System.Drawing.Point(614, 16);
            this.Idade.Name = "Idade";
            this.Idade.Size = new System.Drawing.Size(48, 19);
            this.Idade.TabIndex = 5;
            this.Idade.Text = "Idade";
            // 
            // tbEmpresa
            // 
            this.tbEmpresa.Location = new System.Drawing.Point(357, 178);
            this.tbEmpresa.Name = "tbEmpresa";
            this.tbEmpresa.Size = new System.Drawing.Size(271, 27);
            this.tbEmpresa.TabIndex = 9;
            // 
            // lbTelefone
            // 
            this.lbTelefone.AutoSize = true;
            this.lbTelefone.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTelefone.Location = new System.Drawing.Point(20, 86);
            this.lbTelefone.Name = "lbTelefone";
            this.lbTelefone.Size = new System.Drawing.Size(70, 19);
            this.lbTelefone.TabIndex = 6;
            this.lbTelefone.Text = "Telefone";
            // 
            // tbDataNascimento
            // 
            this.tbDataNascimento.Location = new System.Drawing.Point(438, 42);
            this.tbDataNascimento.Name = "tbDataNascimento";
            this.tbDataNascimento.Size = new System.Drawing.Size(148, 27);
            this.tbDataNascimento.TabIndex = 3;
            // 
            // lbEndereco
            // 
            this.lbEndereco.AutoSize = true;
            this.lbEndereco.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEndereco.Location = new System.Drawing.Point(156, 86);
            this.lbEndereco.Name = "lbEndereco";
            this.lbEndereco.Size = new System.Drawing.Size(73, 19);
            this.lbEndereco.TabIndex = 7;
            this.lbEndereco.Text = "Endereço";
            // 
            // tbIdade
            // 
            this.tbIdade.Location = new System.Drawing.Point(618, 42);
            this.tbIdade.Name = "tbIdade";
            this.tbIdade.Size = new System.Drawing.Size(56, 27);
            this.tbIdade.TabIndex = 4;
            // 
            // tbEndereco
            // 
            this.tbEndereco.Location = new System.Drawing.Point(160, 111);
            this.tbEndereco.Name = "tbEndereco";
            this.tbEndereco.Size = new System.Drawing.Size(348, 27);
            this.tbEndereco.TabIndex = 6;
            // 
            // tbTelefone
            // 
            this.tbTelefone.Location = new System.Drawing.Point(23, 111);
            this.tbTelefone.Name = "tbTelefone";
            this.tbTelefone.Size = new System.Drawing.Size(131, 27);
            this.tbTelefone.TabIndex = 5;
            // 
            // painelFormulario
            // 
            this.painelFormulario.Controls.Add(this.tbSaldo);
            this.painelFormulario.Controls.Add(this.lbSaldo);
            this.painelFormulario.Controls.Add(this.btCriarConta);
            this.painelFormulario.Controls.Add(this.btCancelar);
            this.painelFormulario.Controls.Add(this.btLimpar);
            this.painelFormulario.Controls.Add(this.rbCorrente);
            this.painelFormulario.Controls.Add(this.rbPoupanca);
            this.painelFormulario.Controls.Add(this.label2);
            this.painelFormulario.Controls.Add(this.tbNome);
            this.painelFormulario.Controls.Add(this.lbEmpresa);
            this.painelFormulario.Controls.Add(this.tbCPF);
            this.painelFormulario.Controls.Add(this.lbEmail);
            this.painelFormulario.Controls.Add(this.lbNome);
            this.painelFormulario.Controls.Add(this.lbComplemento);
            this.painelFormulario.Controls.Add(this.lbCPF);
            this.painelFormulario.Controls.Add(this.tbComplemento);
            this.painelFormulario.Controls.Add(this.lbDataNascimento);
            this.painelFormulario.Controls.Add(this.tbEmail);
            this.painelFormulario.Controls.Add(this.Idade);
            this.painelFormulario.Controls.Add(this.tbEmpresa);
            this.painelFormulario.Controls.Add(this.lbTelefone);
            this.painelFormulario.Controls.Add(this.tbDataNascimento);
            this.painelFormulario.Controls.Add(this.lbEndereco);
            this.painelFormulario.Controls.Add(this.tbIdade);
            this.painelFormulario.Controls.Add(this.tbEndereco);
            this.painelFormulario.Controls.Add(this.tbTelefone);
            this.painelFormulario.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.painelFormulario.Location = new System.Drawing.Point(3, 36);
            this.painelFormulario.Name = "painelFormulario";
            this.painelFormulario.Size = new System.Drawing.Size(696, 291);
            this.painelFormulario.TabIndex = 21;
            // 
            // tbSaldo
            // 
            this.tbSaldo.Location = new System.Drawing.Point(223, 245);
            this.tbSaldo.Name = "tbSaldo";
            this.tbSaldo.Size = new System.Drawing.Size(100, 27);
            this.tbSaldo.TabIndex = 11;
            // 
            // lbSaldo
            // 
            this.lbSaldo.AutoSize = true;
            this.lbSaldo.Location = new System.Drawing.Point(219, 220);
            this.lbSaldo.Name = "lbSaldo";
            this.lbSaldo.Size = new System.Drawing.Size(47, 19);
            this.lbSaldo.TabIndex = 26;
            this.lbSaldo.Text = "Saldo";
            // 
            // painelTitulo
            // 
            this.painelTitulo.BackColor = System.Drawing.Color.CornflowerBlue;
            this.painelTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.painelTitulo.Location = new System.Drawing.Point(0, 0);
            this.painelTitulo.Name = "painelTitulo";
            this.painelTitulo.Size = new System.Drawing.Size(699, 36);
            this.painelTitulo.TabIndex = 22;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 330);
            this.Controls.Add(this.painelFormulario);
            this.Controls.Add(this.painelTitulo);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Abertura de Conta";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.painelFormulario.ResumeLayout(false);
            this.painelFormulario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCriarConta;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btLimpar;
        private System.Windows.Forms.RadioButton rbCorrente;
        private System.Windows.Forms.RadioButton rbPoupanca;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.Label lbEmpresa;
        private System.Windows.Forms.TextBox tbCPF;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbComplemento;
        private System.Windows.Forms.Label lbCPF;
        private System.Windows.Forms.TextBox tbComplemento;
        private System.Windows.Forms.Label lbDataNascimento;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label Idade;
        private System.Windows.Forms.TextBox tbEmpresa;
        private System.Windows.Forms.Label lbTelefone;
        private System.Windows.Forms.TextBox tbDataNascimento;
        private System.Windows.Forms.Label lbEndereco;
        private System.Windows.Forms.TextBox tbIdade;
        private System.Windows.Forms.TextBox tbEndereco;
        private System.Windows.Forms.TextBox tbTelefone;
        private System.Windows.Forms.Panel painelFormulario;
        private System.Windows.Forms.Panel painelTitulo;
        private System.Windows.Forms.TextBox tbSaldo;
        private System.Windows.Forms.Label lbSaldo;
    }
}