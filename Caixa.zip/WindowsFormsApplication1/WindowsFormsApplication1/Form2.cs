﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace WindowsFormsApplication1
{

    public partial class Form2 : Form
    {

        public List<Conta> ContasAbertas = new List<Conta>();
        public Form2(List<Conta> ContasAbertasForm1)
        {
            InitializeComponent();
            ContasAbertas = ContasAbertasForm1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Operação abortada!");
            Application.Exit();
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            tbNome.Clear();
            tbCPF.Clear();
            tbDataNascimento.Clear();
            tbIdade.Clear();
            tbTelefone.Clear();
            tbEndereco.Clear();
            tbComplemento.Clear();
            tbEmail.Clear();
            tbEmpresa.Clear();
            tbSaldo.Clear();
        }

        private void btCriarConta_Click(object sender, EventArgs e)
        {
            var conta = new Conta();
            conta.Nome = tbNome.Text;
            conta.Cpf = tbCPF.Text;
            conta.DataNascimento = tbDataNascimento.Text;
            conta.Idade = int.Parse(tbIdade.Text);
            conta.Telefone = tbTelefone.Text;
            conta.Endereco = tbTelefone.Text;
            conta.Complemento = tbComplemento.Text;
            conta.Email = tbEmail.Text;
            conta.Empresa = tbEmpresa.Text;
            conta.Saldo = float.Parse(tbSaldo.Text.ToString(CultureInfo.InvariantCulture));

            ContasAbertas.Add(conta);
            // Caixa.ContasAbertas.Add(conta);
            // quando usamos o static a sua propriedade já fica criada (instanciada)

            tbNome.Clear();
            tbCPF.Clear();
            tbDataNascimento.Clear();
            tbIdade.Clear();
            tbTelefone.Clear();
            tbEndereco.Clear();
            tbComplemento.Clear();
            tbEmail.Clear();
            tbEmpresa.Clear();
            tbSaldo.Clear();
        }
    }
}
